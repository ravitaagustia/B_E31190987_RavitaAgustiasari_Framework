<?php
//deklarasi class
class buku {

    // deklarasi property
	    public $judul_buku;
	    public $pengarang;
	    public $penerbit;
	    public $tahun_terbit;
	    public $cetakan; 
	    
      }

  ?>
