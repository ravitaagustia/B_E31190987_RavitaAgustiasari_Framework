<!DOCTYPE html>
<html>
<head>
	<title>Controller, Model dan View</title>
</head>
<body>
	<h2><? echo $text ?></h2>
	<h3>Menggunakan Controller, Model dan view!</h3>

</body>
</html>