<!DOCTYPE html>
<html>
<head></head>
<body>
	<h2>Hello World CI!</h2>
	<h3>Menggunakan Controller san View!</h3>

</body>
</html>