<?php

class Hello extends CI_Controller{
	public function intex(){

		$this -> load -> view ('helloview');
	}
}
?>