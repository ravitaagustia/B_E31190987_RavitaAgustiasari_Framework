<!DOCTYPE html>
<html>
<head>
	<title>Controller dan view lebih dari 1 variabel</title>
</head>
<body>

	<h2>Menggirim Data dari Controller ke view</h2>

	variabel1: <?php echo variabel1; ?></br>

	variabel2: <?php echo variabel2; ?></br>

</body>
</html>